-- PayDown web app schema. Run in the Supabase SQL editor for the project
-- referenced in NEXT_PUBLIC_SUPABASE_URL. Uses Supabase Auth (auth.users) —
-- this does NOT touch the legacy `easyseat-user-paydown` table used by the
-- desktop app.

create extension if not exists pgcrypto;

create table if not exists public.income_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  category text not null check (category in ('paycheck','retirement','governmental','checking')),
  slot int not null check (slot between 1 and 12),
  source text not null default '',
  amount numeric not null default 0,
  updated_at timestamptz not null default now(),
  unique (user_id, category, slot)
);

create table if not exists public.debt_monthly_bills (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  slot int not null check (slot between 1 and 15),
  chargeable boolean not null default false,
  source text not null default '',
  amount numeric not null default 0,
  updated_at timestamptz not null default now(),
  unique (user_id, slot)
);

create table if not exists public.debt_living_expenses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  slot int not null check (slot between 1 and 15),
  chargeable boolean not null default false,
  source text not null default '',
  amount numeric not null default 0,
  updated_at timestamptz not null default now(),
  unique (user_id, slot)
);

create table if not exists public.debt_loans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  slot int not null check (slot between 1 and 10),
  source text not null default '',
  payment numeric not null default 0,
  balance numeric not null default 0,
  interest_rate numeric not null default 0,
  outstanding_interest numeric not null default 0,
  updated_at timestamptz not null default now(),
  unique (user_id, slot)
);

create table if not exists public.debt_credits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  slot int not null check (slot between 1 and 12),
  source text not null default '',
  payment numeric not null default 0,
  balance numeric not null default 0,
  interest_rate numeric not null default 0,
  credit_limit numeric not null default 0,
  type text not null default 'CC' check (type in ('CC','LOC')),
  updated_at timestamptz not null default now(),
  unique (user_id, slot)
);

create table if not exists public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  income_total numeric not null default 0,
  mortgage_rent_payment numeric not null default 0,
  total_monthly_exp numeric not null default 0,
  total_debts numeric not null default 0,
  chargeable_expenses numeric not null default 0,
  non_chargeable_expenses numeric not null default 0,
  credit_score_1 text not null default '',
  credit_score_2 text not null default '',
  updated_at timestamptz not null default now()
);

alter table public.income_entries enable row level security;
alter table public.debt_monthly_bills enable row level security;
alter table public.debt_living_expenses enable row level security;
alter table public.debt_loans enable row level security;
alter table public.debt_credits enable row level security;
alter table public.user_settings enable row level security;

do $$
declare
  t text;
begin
  for t in select unnest(array[
    'income_entries','debt_monthly_bills','debt_living_expenses',
    'debt_loans','debt_credits','user_settings'
  ]) loop
    execute format(
      'create policy "owner_select" on public.%I for select using (auth.uid() = user_id);', t
    );
    execute format(
      'create policy "owner_insert" on public.%I for insert with check (auth.uid() = user_id);', t
    );
    execute format(
      'create policy "owner_update" on public.%I for update using (auth.uid() = user_id) with check (auth.uid() = user_id);', t
    );
    execute format(
      'create policy "owner_delete" on public.%I for delete using (auth.uid() = user_id);', t
    );
  end loop;
end $$;
