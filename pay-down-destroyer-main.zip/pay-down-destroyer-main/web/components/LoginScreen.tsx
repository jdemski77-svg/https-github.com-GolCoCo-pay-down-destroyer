'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';
import { supabase } from '@/lib/supabaseClient';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<'login' | 'reset'>('login');

  useEffect(() => {
    try {
      const saved = localStorage.getItem('paydown_remember_email');
      if (saved) setEmail(saved);
    } catch {
      // ignore storage failures (private browsing, etc.)
    }
  }, []);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!email || !password) {
      setError('Please enter username and password.');
      return;
    }
    setBusy(true);
    const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (signInError) {
      setError('Incorrect username or password. Please check again.');
      return;
    }
    try {
      if (remember) localStorage.setItem('paydown_remember_email', email);
      else localStorage.removeItem('paydown_remember_email');
    } catch {
      // ignore storage failures (private browsing, etc.)
    }
    // No navigation needed: the auth-state listener in the parent re-renders into AppScreen.
  }

  async function handleReset(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setInfo('');
    if (!email) {
      setError('Please enter your username (email) first.');
      return;
    }
    setBusy(true);
    const { error: resetError } = await supabase.auth.resetPasswordForEmail(email);
    setBusy(false);
    if (resetError) {
      setError(resetError.message);
      return;
    }
    setInfo('If that email has an account, a password reset link has been sent.');
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-100">
      <div className="w-[653px] max-w-[95vw] overflow-hidden rounded-md shadow-xl">
        <div className="flex items-center bg-brand-blue px-4 py-2">
          <span className="font-login text-lg text-white">Pay Down</span>
        </div>
        <div className="flex gap-6 bg-white p-6">
          <div className="hidden shrink-0 sm:block">
            <Image src="/logo.png" alt="Pay Down" width={240} height={240} />
          </div>
          <form onSubmit={mode === 'login' ? handleLogin : handleReset} className="flex w-full flex-col justify-center gap-3">
            <div>
              <label className="field-label">Username</label>
              <input
                className="field-input"
                type="email"
                autoComplete="username"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            {mode === 'login' && (
              <div>
                <label className="field-label">Password</label>
                <input
                  className="field-input"
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            )}
            {mode === 'login' && (
              <label className="flex items-center gap-2 text-xs font-semibold uppercase text-gray-600">
                <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
                Remember me
              </label>
            )}
            {error && <p className="text-sm text-brand-red">{error}</p>}
            {info && <p className="text-sm text-brand-green">{info}</p>}
            <button
              type="submit"
              disabled={busy}
              className="rounded bg-brand-blue px-4 py-2 text-sm font-bold text-white hover:opacity-90 disabled:opacity-50"
            >
              {mode === 'login' ? 'Login' : 'Send reset link'}
            </button>
            <button
              type="button"
              className="text-left text-xs text-brand-blue underline"
              onClick={() => {
                setMode(mode === 'login' ? 'reset' : 'login');
                setError('');
                setInfo('');
              }}
            >
              {mode === 'login' ? 'Forgot password?' : 'Back to login'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
