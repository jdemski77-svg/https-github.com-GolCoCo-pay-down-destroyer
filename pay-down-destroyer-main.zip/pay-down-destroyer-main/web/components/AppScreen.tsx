'use client';

import { useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import TopBar from '@/components/TopBar';
import IncomeTab from '@/components/tabs/IncomeTab';
import DebtsTab from '@/components/tabs/DebtsTab';
import IdentifyImplementTab from '@/components/tabs/IdentifyImplementTab';

type TabKey = 'income' | 'debts' | 'implement';

const TABS: { key: TabKey; label: string; activeClass: string }[] = [
  { key: 'income', label: 'Organize Income', activeClass: 'bg-brand-green text-white' },
  { key: 'debts', label: 'Organize Debts', activeClass: 'bg-brand-red text-white' },
  { key: 'implement', label: 'Identify & Implement', activeClass: 'bg-brand-magenta text-white' },
];

export default function AppScreen({ session }: { session: Session }) {
  const [tab, setTab] = useState<TabKey>('income');

  return (
    <div className="flex min-h-screen flex-col">
      <TopBar />
      <div className="flex border-b border-gray-300 bg-white">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-5 py-3 text-sm font-display font-bold uppercase tracking-wide ${
              tab === t.key ? t.activeClass : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div className="flex-1 overflow-auto bg-gray-100 p-4">
        {tab === 'income' && <IncomeTab userId={session.user.id} />}
        {tab === 'debts' && <DebtsTab userId={session.user.id} />}
        {tab === 'implement' && <IdentifyImplementTab userId={session.user.id} />}
      </div>
    </div>
  );
}
