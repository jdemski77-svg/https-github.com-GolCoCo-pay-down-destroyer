'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';
import { supabase } from '@/lib/supabaseClient';

export default function TopBar() {
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    setNow(new Date());
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  async function handleLogout() {
    await supabase.auth.signOut();
    // No navigation needed: the auth-state listener in the parent re-renders into LoginScreen.
  }

  return (
    <div className="flex items-center justify-between bg-brand-blue px-4 py-2 text-white">
      <div className="flex items-center gap-2">
        <Image src="/logo.png" alt="Pay Down" width={28} height={28} className="rounded" />
        <span className="font-login text-sm">Pay Down</span>
      </div>
      <div className="flex items-center gap-4 text-xs">
        <span suppressHydrationWarning>{now ? now.toLocaleString() : ''}</span>
        <button onClick={handleLogout} className="rounded bg-white/10 px-3 py-1 font-semibold hover:bg-white/20">
          Logout
        </button>
      </div>
    </div>
  );
}
