'use client';

import { useEffect, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabaseClient';
import LoginScreen from '@/components/LoginScreen';
import AppScreen from '@/components/AppScreen';

export default function Home() {
  const [session, setSession] = useState<Session | null | undefined>(undefined);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  if (session === undefined) {
    return <div className="flex h-screen items-center justify-center text-gray-500">Loading…</div>;
  }
  if (session === null) {
    return <LoginScreen />;
  }
  return <AppScreen session={session} />;
}
