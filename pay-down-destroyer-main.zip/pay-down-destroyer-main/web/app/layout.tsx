import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Pay Down',
  description: 'Organize your income and debts, then Pay Down strategically.',
  icons: { icon: '/logo.png' },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
