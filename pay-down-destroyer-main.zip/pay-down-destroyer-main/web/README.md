# Pay Down — Web

Next.js rewrite of the PayDown WPF desktop app (`../PayDown`), rebuilt as a statically-exported
web app with the same UI/UX, using Supabase for auth and data.

## Stack

- Next.js 16 (App Router), statically exported (`output: 'export'` in `next.config.js`) — no
  server runtime required, so it can be hosted anywhere that serves static files, including Base44.
- Supabase Auth (email/password) + Postgres, called directly from the browser with the anon key.
- Tailwind CSS.

## 1. Local setup

```bash
npm install
cp .env.local.example .env.local   # fill in NEXT_PUBLIC_SUPABASE_ANON_KEY
npm run dev
```

## 2. Supabase setup (one-time)

1. Open the SQL editor for the project at `NEXT_PUBLIC_SUPABASE_URL` (`xfospiidchxnhsjfjlpk`).
2. Run `supabase/migration.sql`. It creates `income_entries`, `debt_monthly_bills`,
   `debt_living_expenses`, `debt_loans`, `debt_credits`, `user_settings` — all scoped to
   `auth.uid()` via RLS. It does **not** touch the legacy `easyseat-user-paydown` table used by
   the desktop app.
3. In Authentication settings, enable Email/Password sign-in. Decide how existing desktop-app
   users get web accounts — **this needs a product decision, not a default**:
   - Recommended: bulk-import the 287 `easyseat-user-paydown` emails into `auth.users` via the
     Admin API with `email_confirm: true` and a random password, then email each user a
     password-reset link before launch. Do **not** reuse their existing plaintext passwords.
   - Alternative: let users sign up fresh and self-identify; simpler, but loses continuity with
     desktop accounts.
4. See the security note below before doing any of this.

### Security note (do this regardless of the above)

The anon key hardcoded in the desktop app's `Utils/HardCode.cs` currently has read access to
`easyseat-user-paydown`, which contains **287 real users' plaintext passwords and emails** with no
RLS. This was confirmed live against the API during this rewrite and is independent of the new
app. Recommended before shipping anything further: rotate that anon key and add RLS to that table
(this will require shipping an updated desktop build with the new key).

## 3. Build

```bash
npm run build
```

Output is a static site in `out/`.

## 4. Deploy to Base44

Base44's CLI can host an existing Next.js app's static build:

```bash
npm install --save-dev base44
npx base44 create paydown-web -p .     # registers the project, writes base44/.app.jsonc
npm run build                           # produces out/
npx base44 deploy                       # builds/deploys the site
```

This wires Base44 as a static host only — all auth and data calls go straight from the browser to
Supabase, so Base44 doesn't need its own backend/entities for this app. Run `npx base44 create`
interactively once (it requires your Base44 account login); after that, `npx base44 deploy` can be
re-run for subsequent releases.
