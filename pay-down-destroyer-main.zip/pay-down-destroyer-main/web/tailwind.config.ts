import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          blue: '#2B579A',
          green: '#006400',
          red: '#8B0000',
          magenta: '#8B008B',
        },
      },
      fontFamily: {
        display: ['"Arial Black"', 'Arial', 'sans-serif'],
        login: ['Cinzel', '"Copperplate Gothic Light"', 'serif'],
      },
    },
  },
  plugins: [],
};

export default config;
